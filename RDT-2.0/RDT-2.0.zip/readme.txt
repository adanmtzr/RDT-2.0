Building Library and Programs
--------------------------

Simply copy everything into a folder and type "make".

Run the server then run the client.